﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace CPRG211_Lab2
{
    internal class PartTime : Employee
    {
        private double rate;

        public double Rate
        {
            get { return rate; }
            set { rate = value; }
        }

        public PartTime(string id, string name, string address, double rate) 
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.rate = rate;
        }

        public double CalculatePay(double rt, int hr)
        {
            rate = rt * hr;
            return rate;
        }
    }
}
