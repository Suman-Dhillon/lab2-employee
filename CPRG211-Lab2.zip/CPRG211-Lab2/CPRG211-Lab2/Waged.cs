﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPRG211_Lab2
{
    internal class Waged : Employee
    {
        private double rate;

        public double Rate { get { return rate; } }

        public Waged(string id, string name, string address, double rate)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.rate = rate;
        }
        public double CalculatePay(double rt, int hr)
        {
            if (hr > 40)
            {
                rate = rt * 40 + rt * (hr - 40) * 1.5;
            }
            else
            {
                rate = rt * hr;
            }          
            return rate;
        }

        public string maxWage()
        {
            return (" ");
        }
    }
}
